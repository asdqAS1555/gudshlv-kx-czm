"""
A folder with asynchronous and synchronous extensions.
"""
