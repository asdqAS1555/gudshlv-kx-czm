Updated typing_extensions to 4.6.0
