
.. _`pip config`:

==========
pip config
==========


Usage
=====

.. tab:: Unix/macOS

   .. pip-command-usage:: config "python -m pip"

.. tab:: Windows

   .. pip-command-usage:: config "py -m pip"


Description
===========

.. pip-command-description:: config


Options
=======

.. pip-command-options:: config
